#include "brandk1window.h"
#include "ui_brandk1window.h"
#include <string>
#include <sstream>
#include <algorithm>
#include <QString>
#include <QDir>

using namespace std;

// change base folder here
string folderName = "C:/Users/asus/Desktop/folderLatihan/woi";

int myCount = 0;
void makeSure(QDir dirq, QString s) {
    if (!dirq.exists()) {
        dirq.mkpath(s);
    }
}

string duplicate = folderName;
int baseLength = folderName.length();

QDir dir(QString::fromStdString(duplicate));
BrandK1Window::BrandK1Window(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::BrandK1Window)
{
    ui->setupUi(this);
    ui->textEdit->setReadOnly(true);
    ui->textEdit->insertPlainText(QString::fromStdString("baseFolder>"));
    ui->label->setText("baseFolder");
}

BrandK1Window::~BrandK1Window()
{
    delete ui;
}

void BrandK1Window::on_lineEdit_returnPressed() {
    myCount+=1;
    if (myCount == 1) {
        makeSure(dir, QString::fromStdString(duplicate));
        QDir dir0(QString::fromStdString(duplicate));
        dir = dir0;
    }
    QString qcommand = ui->lineEdit->text();
    string command = qcommand.toStdString();
    ui->lineEdit->setText("");
    ui->textEdit->insertPlainText(qcommand + "\n");
    if (command.find('&') != -1) {
        ui->textEdit->insertPlainText("  Please input one command at a time\n");
    }
    else if (command.substr(0,3) == "md ") {

        string newFolder = command.substr(3,command.length()-3);

        if (newFolder.find('/') != -1) {
            ui->textEdit->insertPlainText("  invalid folder name\n");
        }
        else {
            QDir dir2(dir.path() + "/" + QString::fromStdString(newFolder));
            if (dir2.exists()) {
                ui->textEdit->insertPlainText("  folder already existed\n");
            }
            else {
                dir.mkdir(QString::fromStdString(newFolder));
            }
        }
    }
    else if (command.substr(0,5) == "cd ..") {
        if (dir.path().length() == baseLength) {}
        else {
            if(dir.cdUp()) {}
        }
    }
    else if (command.substr(0,3) == "cd ") {
        string newFolder = command.substr(3,command.length()-3);
        if (newFolder.find("/") != -1) {
            ui->textEdit->insertPlainText("  Please enter 1 folder at a time\n");
        }
        else {
            if (dir.cd(dir.path() + "/" + QString::fromStdString(newFolder))) {}
            else {
                ui->textEdit->insertPlainText("  Cannot find that\n");
            }
        }
    }
    else if (command.length() == 3 and command.substr(0,3) == "dir") {
        int counter = 1;
        dir.setPath(dir.path());
        foreach (QFileInfo var, dir.entryInfoList()) {
            if (counter >= 3) {
                ui->textEdit->insertPlainText("  " + var.fileName() + "\n");
            }
            counter += 1;
        }
    }
    else if (command.substr(0,3) == "rd ") {
        string newFolder = command.substr(3,command.length()-3);
        QDir dir3(dir.path() + "/" + QString::fromStdString(newFolder));
        if (!dir3.exists()) {
            ui->textEdit->insertPlainText("  Cannot find that\n");
        }
        else if (dir3.removeRecursively()) {

        }
        else {
            ui->textEdit->insertPlainText("  Please try again\n");
        }
    }
    else if (command.substr(0,5) == "echo ") {
        ui->textEdit->insertPlainText(QString::fromStdString(command.substr(5,command.length()-5))+"\n");
    }
    else if (command.length()>4){
        if (command.substr(command.length()-4,4) == ".txt") {
            if (QFileInfo(dir.path()+"/"+QString::fromStdString(command)).exists()) {
                ui->textEdit->insertPlainText("  Opening " + QString::fromStdString(command) + "...\n");
                emit sendMessage(dir.path()+"/"+QString::fromStdString(command));
            } else {
                ui->textEdit->insertPlainText("  Cannot find that\n");
            }

        }
    }
    else {

    }

    QString qcurrent = dir.path().mid(baseLength,dir.path().length()+1-baseLength);
    qcurrent = "baseFolder" + qcurrent;
    ui->label->setText(qcurrent);
    ui->textEdit->insertPlainText(qcurrent + ">");
}
