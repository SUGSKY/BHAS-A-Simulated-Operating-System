#ifndef BRANDK1WINDOW_H
#define BRANDK1WINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class BrandK1Window; }
QT_END_NAMESPACE

class BrandK1Window : public QMainWindow
{
    Q_OBJECT

public:
    BrandK1Window(QWidget *parent = nullptr);
    ~BrandK1Window();
signals:
    void sendMessage(const QString &msg);
private slots:
    void on_lineEdit_returnPressed();

private:
    Ui::BrandK1Window *ui;
};
#endif // BRANDK1WINDOW_H
